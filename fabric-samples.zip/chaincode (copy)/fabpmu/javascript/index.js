/*
 * SPDX-License-Identifier: Apache-2.0
 */

'use strict';

const FabPMU = require('./lib/fabpmu');

module.exports.FabPMU = FabPMU;
module.exports.contracts = [ FabPMU ];
